import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './CrearEnsayo.css';

const CrearEnsayo = ({ usuario }) => {
  const [materias, setMaterias] = useState([]);
  const [materiaId, setMateriaId] = useState('');
  const [preguntas, setPreguntas] = useState([]);
  const [nombre, setNombre] = useState('');
  const [preguntasSeleccionadas, setPreguntasSeleccionadas] = useState([]);
  const token = localStorage.getItem('token');

  useEffect(() => {
  axios.get('http://localhost:3000/api/materias', {
    headers: {
      Authorization: token
    }
  })
  .then(res => setMaterias(res.data))
  .catch(err => console.error(err));
  }, []);

  useEffect(() => {
    if (materiaId) {
      axios.get(`http://localhost:3000/api/ver-preguntas?materia_id=${materiaId}`, {
        headers: { Authorization: token }
      })
      .then(res => setPreguntas(res.data))
      .catch(err => console.error(err));
    } else {
      setPreguntas([]);
    }
  }, [materiaId]);

  const crearEnsayo = () => {
    axios.post('http://localhost:3000/api/crear-ensayo-con-preguntas', {
      nombre,
      docente_id: usuario.id,
      materia_id: materiaId,
      preguntas: preguntasSeleccionadas
    }, {
      headers: { Authorization: token }
    })
    .then(() => alert('Ensayo creado con éxito'))
    .catch(err => console.error(err));
  };

  const togglePregunta = (id) => {
    setPreguntasSeleccionadas(prev =>
      prev.includes(id) ? prev.filter(pid => pid !== id) : [...prev, id]
    );
  };

  return (
    <div className="crear-ensayo-container">
      <h2>Crear Ensayo</h2>

      <input
        type="text"
        placeholder="Nombre del ensayo"
        value={nombre}
        onChange={e => setNombre(e.target.value)}
        className="input-nombre"
      />

      <select
        value={materiaId}
        onChange={e => setMateriaId(e.target.value)}
        className="select-materia"
      >
        <option value="">Seleccione una materia</option>
        {materias.map(m => (
          <option key={m.id} value={m.id}>{m.nombre}</option>
        ))}
      </select>

      {preguntas.length > 0 && (
        <div className="preguntas-box">
          <h4>Seleccionar preguntas:</h4>
          <ul className="lista-preguntas">
            {preguntas.map(p => (
              <li key={p.id}>
                <label>
                  <input
                    type="checkbox"
                    checked={preguntasSeleccionadas.includes(p.id)}
                    onChange={() => togglePregunta(p.id)}
                  />
                  {p.enunciado}
                </label>
              </li>
            ))}
          </ul>
        </div>
      )}

      <button className="btn-crear" onClick={crearEnsayo}>Crear Ensayo</button>
    </div>
  );
};

export default CrearEnsayo;
