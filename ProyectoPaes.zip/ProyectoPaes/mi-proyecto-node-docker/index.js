const express = require('express');
const pool = require('./db'); // Importar la conexión
const authRoutes = require('./routes/auth');
const cors = require('cors');
const materiasRoutes = require('./routes/materias');
const rutasPreguntas = require('./routes/preguntas');
const port = 3000;
const app = express();
const preguntasRoutes = require('./routes/preguntas');


app.use(express.json()); // Para leer JSON
app.use(cors()); // ← ESTO activa CORS para permitir peticiones del frontend

app.use('/api', preguntasRoutes);
app.use('/api', authRoutes); // Registrar las rutas de login
app.use('/api', materiasRoutes);
app.use('/api', rutasPreguntas);
// 👇 Esto va antes de cualquier ruta



// Rutas de prueba
app.get('/save', async (req, res) => {
  try {
    await pool.query('CREATE TABLE IF NOT EXISTS messages (id SERIAL PRIMARY KEY, content TEXT)');
    await pool.query('INSERT INTO messages (content) VALUES ($1)', ['Hola desde PostgreSQL!']);
    res.send('Mensaje guardado en la base de datos');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error');
  }
});

app.get('/messages', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM messages');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error');
  }
});

app.get('/', (req, res) => {
  res.send('¡Bienvenido! Usa /save para guardar un mensaje y /messages para verlos.');
});

const ensayoRoutes = require('./routes/ensayos'); // ✅ importar
app.use('/api', ensayoRoutes); // ✅ usar

const preguntaRoutes = require('./routes/preguntas');
app.use('/api', preguntaRoutes);

const resultadoRoutes = require('./routes/resultados');
app.use('/api', resultadoRoutes);

const respuestaRoutes = require('./routes/respuestas');
app.use('/api', respuestaRoutes);


// ✅ Solo una vez este llamado
app.listen(port, () => {
  console.log(`App corriendo en http://localhost:${port}`);
});
