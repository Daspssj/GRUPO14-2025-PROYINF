
-- Creación de tablas adaptadas a PostgreSQL

CREATE TABLE usuarios (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100),
  correo VARCHAR(100) UNIQUE,
  contrasena VARCHAR(255),
  rol VARCHAR(10) CHECK (rol IN ('alumno', 'docente'))
);

INSERT INTO usuarios (id, nombre, correo, contrasena, rol) VALUES
(1, 'Juan Pérez', 'juan@correo.com', '1234', 'docente'),
(2, 'Camila Yael Loayza Arredondo', 'caca@gmail.com', '123', 'alumno'),
(3, 'Agustin Santibañez', 'agus@gmail.com', '123', 'docente'),
(4, 'alicia', 'ali@gmail.com', '123', 'docente');

SELECT setval('usuarios_id_seq', (SELECT MAX(id) FROM usuarios));

CREATE TABLE materias (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100)
);

INSERT INTO materias (id, nombre) VALUES
(1, 'Lenguaje'),
(2, 'Matematicas1'),
(3, 'Matematicas2'),
(4, 'Biologia'),
(5, 'Quimica'),
(6, 'Fisica'),
(7, 'Historia y ciencias sociales');

CREATE TABLE ensayos (
  id SERIAL PRIMARY KEY,
  nombre VARCHAR(100),
  fecha_creacion DATE,
  docente_id INTEGER REFERENCES usuarios(id),
  materia_id INTEGER REFERENCES materias(id)
);

CREATE TABLE preguntas (
  id SERIAL PRIMARY KEY,
  enunciado TEXT,
  imagen VARCHAR(255),
  opcion_a VARCHAR(255),
  opcion_b VARCHAR(255),
  opcion_c VARCHAR(255),
  opcion_d VARCHAR(255),
  respuesta_correcta VARCHAR(1) CHECK (respuesta_correcta IN ('A','B','C','D')),
  materia_id INTEGER REFERENCES materias(id)
);

CREATE TABLE ensayo_pregunta (
  id SERIAL PRIMARY KEY,
  ensayo_id INTEGER REFERENCES ensayos(id),
  pregunta_id INTEGER REFERENCES preguntas(id)
);

CREATE TABLE resultados (
  id SERIAL PRIMARY KEY,
  ensayo_id INTEGER REFERENCES ensayos(id),
  alumno_id INTEGER REFERENCES usuarios(id),
  puntaje INTEGER,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE respuestas (
  id SERIAL PRIMARY KEY,
  resultado_id INTEGER REFERENCES resultados(id),
  pregunta_id INTEGER REFERENCES preguntas(id),
  respuesta_dada VARCHAR(1) CHECK (respuesta_dada IN ('A','B','C','D')),
  correcta BOOLEAN
);

-- Actualizar secuencia de IDs de usuarios si fuera necesario (solo si insertas manualmente)
-- SELECT setval('usuarios_id_seq', (SELECT MAX(id) FROM usuarios));
