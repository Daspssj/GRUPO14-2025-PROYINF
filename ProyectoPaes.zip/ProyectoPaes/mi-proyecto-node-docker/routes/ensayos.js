const express = require('express');
const router = express.Router();
const pool = require('../db');
const { verificarToken } = require('../middleware/auth');


router.post('/crear-ensayo', async (req, res) => {
  const { nombre, docente_id, materia_id } = req.body;

  if (!nombre || !docente_id || !materia_id) {
    return res.status(400).json({ error: 'Faltan campos obligatorios' });
  }

  try {
    const fecha_creacion = new Date().toISOString().split('T')[0];

    const result = await pool.query(
      'INSERT INTO ensayos (nombre, fecha_creacion, docente_id, materia_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [nombre, fecha_creacion, docente_id, materia_id]
    );

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear ensayo' });
  }
});

router.post('/crear-ensayo-con-preguntas', async (req, res) => {
  const { nombre, docente_id, materia_id, preguntas } = req.body;

  if (!nombre || !docente_id || !materia_id || !Array.isArray(preguntas) || preguntas.length === 0) {
    return res.status(400).json({ error: 'Faltan campos o la lista de preguntas está vacía' });
  }

  try {
    const fecha_creacion = new Date().toISOString().split('T')[0];

    // 1. Crear el ensayo
    const ensayoResult = await pool.query(
      `INSERT INTO ensayos (nombre, fecha_creacion, docente_id, materia_id)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [nombre, fecha_creacion, docente_id, materia_id]
    );

    const ensayoId = ensayoResult.rows[0].id;

    // 2. Insertar relaciones ensayo-pregunta
    const values = preguntas.map((id, index) => `($1, $${index + 2})`).join(',');
    const query = `INSERT INTO ensayo_pregunta (ensayo_id, pregunta_id) VALUES ${values}`;
    await pool.query(query, [ensayoId, ...preguntas]);

    res.status(201).json({ mensaje: 'Ensayo creado con preguntas asociadas', ensayo: ensayoResult.rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear ensayo con preguntas' });
  }
});

router.get('/ver-ensayos', async (req, res) => {
  const { materia_id, docente_id } = req.query;

  let query = 'SELECT * FROM ensayos';
  const conditions = [];
  const values = [];

  if (materia_id) {
    values.push(materia_id);
    conditions.push(`materia_id = $${values.length}`);
  }

  if (docente_id) {
    values.push(docente_id);
    conditions.push(`docente_id = $${values.length}`);
  }

  if (conditions.length > 0) {
    query += ' WHERE ' + conditions.join(' AND ');
  }

  try {
    const result = await pool.query(query, values);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener los ensayos' });
  }
});

router.get('/ver-ensayos-disponibles', verificarToken, async (req, res) => {
  const alumno_id = req.usuario.id;

  if (!alumno_id) {
    return res.status(400).json({ error: 'Falta alumno_id' });
  }

  try {
    const result = await pool.query(`
      SELECT e.id, e.nombre, m.nombre AS materia, e.fecha_creacion
      FROM ensayos e
      JOIN materias m ON e.materia_id = m.id
      WHERE e.id NOT IN (
        SELECT ensayo_id FROM resultados WHERE alumno_id = $1
      )
      ORDER BY e.fecha_creacion DESC
    `, [alumno_id]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener ensayos disponibles' });
  }
});

router.get('/ver-preguntas-del-ensayo', async (req, res) => {
  const { ensayo_id } = req.query;

  if (!ensayo_id) {
    return res.status(400).json({ error: 'Falta ensayo_id' });
  }

  try {
    const result = await pool.query(`
      SELECT p.id, p.enunciado, p.imagen, p.opcion_a, p.opcion_b, p.opcion_c, p.opcion_d
      FROM ensayo_pregunta ep
      JOIN preguntas p ON ep.pregunta_id = p.id
      WHERE ep.ensayo_id = $1
      ORDER BY p.id
    `, [ensayo_id]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener preguntas del ensayo' });
  }
});


module.exports = router;
