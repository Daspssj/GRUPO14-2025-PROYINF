Integrantes:
Agustin Santibañez / Rol: 202204682-1
Sebastian Jaña / Rol: 202273618-6

Ejecucion programa: Para ejecutar correctamente la tienda, se debe descomprimir el archivo principal, y posteriormente agregarlo a la carpeta "htdocs" de xampp
Luego, se deben extraer los php de la carpeta "php" y el archivo "estilo.css" de la carpeta "css", luego se debe importar la base de datos a una llamada
"tarea2bdd" para que de esta forma se conecte a la pagina web.
Ahora disfrutar de comprar.

Supuestos: 
1) Al eliminar un videojuego o consola, no se borran los productos que hayan sido creados en base a estos videojuegos o consolas anteriormente,
esto ya que se busca mantener un registro de todo lo que ha vendido la tienda, entonces al eliminar un juego o consola de la base de datos, no significa
eliminar tambien las ventas asociadas anteriormente.

